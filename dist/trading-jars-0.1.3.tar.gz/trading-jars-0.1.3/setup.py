from setuptools import setup

setup(
    name='trading-jars',
    version='0.1.3',
    py_modules=['trading-jars']
)